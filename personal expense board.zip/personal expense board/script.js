// Store expenses
let expenses = [];


// Add Expense
function addExpense() {

    let name =
        document.getElementById("name").value;

    let amount =
        Number(document.getElementById("amount").value);

    let category =
        document.getElementById("category").value;

    let date =
        document.getElementById("date").value;


    // Check input
    if (name == "" || amount <= 0 || date == "") {

        alert("Please enter all details");

        return;
    }


    // Create expense
    let expense = {

        name: name,
        amount: amount,
        category: category,
        date: date

    };


    // Add to array
    expenses.push(expense);


    // Update screen
    showExpenses();


    // Clear form
    document.getElementById("name").value = "";
    document.getElementById("amount").value = "";
    document.getElementById("date").value = "";
}


// Show expenses
function showExpenses() {

    let total = 0;

    let food = 0;
    let travel = 0;
    let education = 0;
    let entertainment = 0;


    // Calculate totals
    expenses.forEach(function(expense) {

        total = total + expense.amount;


        if (expense.category == "Food") {
            food = food + expense.amount;
        }

        if (expense.category == "Travel") {
            travel = travel + expense.amount;
        }

        if (expense.category == "Education") {
            education = education + expense.amount;
        }

        if (expense.category == "Entertainment") {
            entertainment =
                entertainment + expense.amount;
        }

    });


    // Display totals
    document.getElementById("total").innerHTML =
        "₹" + total;

    document.getElementById("food").innerHTML =
        "₹" + food;

    document.getElementById("travel").innerHTML =
        "₹" + travel;

    document.getElementById("education").innerHTML =
        "₹" + education;

    document.getElementById("entertainment").innerHTML =
        "₹" + entertainment;


    // Show visual bars
    let highest =
        Math.max(
            food,
            travel,
            education,
            entertainment,
            1
        );


    document.getElementById("foodBar").style.width =
        (food / highest * 100) + "%";

    document.getElementById("travelBar").style.width =
        (travel / highest * 100) + "%";

    document.getElementById("educationBar").style.width =
        (education / highest * 100) + "%";

    document.getElementById("entertainmentBar").style.width =
        (entertainment / highest * 100) + "%";


    // Display expense cards
    let list = "";


    expenses.forEach(function(expense) {

        list += `

            <div class="expense">

                <div>

                    <h3>${expense.name}</h3>

                    <p>
                        Category: ${expense.category}
                    </p>

                    <p>
                        Date: ${expense.date}
                    </p>

                </div>

                <h3>
                    ₹${expense.amount}
                </h3>

            </div>

        `;

    });


    document.getElementById("expenseList").innerHTML =
        list;
}